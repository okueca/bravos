export default function getVariation(placement) {
  return placement.split('-')[1];
};
