/*!
 * Bootstrap-select v1.13.18 (https://developer.snapappointments.com/bootstrap-select)
 *
 * Copyright 2012-2020 SnapAppointments, LLC
 * Licensed under MIT (https://github.com/snapappointments/bootstrap-select/blob/master/LICENSE)
 */

!function(e,t){void 0===e&&void 0!==window&&(e=window),"function"==typeof define&&define.amd?define(["jquery"],function(e){return t(e)}):"object"==typeof module&&module.exports?module.exports=t(require("jquery")):t(e.jQuery)}(this,function(e){e.fn.selectpicker.defaults={noneSelectedText:"Tidak ada yang dipilih",noneResultsText:"Tidak ada yang cocok {0}",countSelectedText:"{0} terpilih",maxOptionsText:["Mencapai batas (maksimum {n})","Mencapai batas grup (maksimum {n})"],selectAllText:"Pilih Semua",deselectAllText:"Hapus Semua",multipleSeparator:", "}});
